package com.jarvis.mobile;
public final class ParserSmokeTest {
    private static void check(String spoken, CommandParser.Type expected) {
        CommandParser.Result r = CommandParser.parse(spoken);
        if (r.type != expected) throw new AssertionError(spoken + " -> " + r.type + "; expected " + expected);
    }
    public static void main(String[] ignored) {
        check("Jarvis, WhatsApp खोलो", CommandParser.Type.OPEN_APP);
        check("नीचे स्क्रॉल करो", CommandParser.Type.SCROLL_DOWN);
        check("go back", CommandParser.Type.BACK);
        check("torch on", CommandParser.Type.TORCH_ON);
        check("flashlight off", CommandParser.Type.TORCH_OFF);
        check("write hello world", CommandParser.Type.TYPE);
        check("click submit", CommandParser.Type.TAP);
        check("call Mom", CommandParser.Type.CALL);
        check("set alarm at 7:30 am", CommandParser.Type.ALARM);
        check("timer 5 minutes", CommandParser.Type.TIMER);
        check("search cute cats", CommandParser.Type.SEARCH_WEB);
        check("youtube पर lo-fi music सर्च करो", CommandParser.Type.SEARCH_YOUTUBE);
        check("open wifi settings", CommandParser.Type.OPEN_SETTINGS);
        check("read notifications", CommandParser.Type.READ_NOTIFICATIONS);
        check("मम्मी को फोन लगाओ", CommandParser.Type.CALL);
        check("lock screen", CommandParser.Type.LOCK);
        check("go home", CommandParser.Type.HOME);
        check("swipe left", CommandParser.Type.SWIPE_LEFT);
        check("message 9876543210 hi", CommandParser.Type.MESSAGE);
        CommandParser.Result app = CommandParser.parse("Jarvis, WhatsApp खोलो");
        if (!"whatsapp".equals(app.argument)) throw new AssertionError("app argument parsing: " + app.argument);
        CommandParser.Result yt = CommandParser.parse("YouTube पर lo-fi music सर्च करो");
        if (!"lo-fi music".equals(yt.argument)) throw new AssertionError("YouTube argument parsing: " + yt.argument);
        System.out.println("21 voice-command smoke tests PASS");
    }
}

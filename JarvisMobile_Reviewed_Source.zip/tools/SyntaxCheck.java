import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.io.File;
import java.util.*;
public class SyntaxCheck {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> diags = new DiagnosticCollector<>();
        StandardJavaFileManager fm = compiler.getStandardFileManager(diags,null,null);
        List<File> files = new ArrayList<>();
        for(String name:args) files.add(new File(name));
        JavacTask task = (JavacTask)compiler.getTask(null,fm,diags,Arrays.asList("-proc:none"),null,fm.getJavaFileObjectsFromFiles(files));
        task.parse();
        for (Diagnostic<?> d:diags.getDiagnostics()) if(d.getKind()==Diagnostic.Kind.ERROR) System.err.println(d);
        if(diags.getDiagnostics().stream().anyMatch(d->d.getKind()==Diagnostic.Kind.ERROR)) System.exit(1);
        System.out.println("Java AST syntax parsing PASS: "+files.size()+" source files");
    }
}

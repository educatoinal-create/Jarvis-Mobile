# JARVIS Mobile — Voice-Control Android Assistant (Source Project)

**Status:** Android Studio / Gradle source project, **not a compiled APK**.

- Application ID: `com.jarvis.mobile`
- Minimum Android: 8.0 (API 26)
- Compile SDK: 35; target SDK: 35
- Java: 17; Android Gradle Plugin: 8.9.2; Gradle: 8.11.1
- Dependencies: Android built-in APIs; no third-party app SDKs.

This package includes a GitHub Actions workflow that can compile an **installable debug APK**. The machine used to prepare this package did not have the Android SDK, Gradle, or network access to Maven artifacts, so **an APK could not be compiled or installed on a real device here**. Pure Java command parsing and Java/XML source syntax were verified locally; Android runtime features still require device testing.

## Included features

| Feature | What happens |
|---|---|
| Push-to-talk | Tap **START VOICE COMMAND** in JARVIS and speak Hindi or English |
| Floating mic shortcut | With overlay permission, a movable bubble is shown over apps. Tap to start one speech-recognition session |
| Open apps | Finds visible launcher apps by label or package name (`open WhatsApp`, `YouTube खोलो`) |
| Navigate | `go back`, `home screen`, `recent apps`, notifications shade, quick settings, lock screen via user-enabled Accessibility |
| Touch / type / scroll | `click Search`, `type hello`, `scroll down`, `swipe left`; some secure actions are blocked |
| Utilities | Torch, music volume, battery percentage, current time, settings screen, camera, web and YouTube search |
| Contacts | With Contacts permission, looks up a matching person and **opens the dialer**. Call isn't placed automatically |
| SMS | `message 9876543210 Hello` opens an SMS **draft**; sending remains manual |
| Alarms & timers | `set alarm at 7:30 am`, `timer 5 minutes` use installed clock app |
| Notification reading | With separately granted notification access, the assistant can read up to five active notifications on request; attempts to skip OTP alerts |
| AI fallback | Optional: unknown commands/questions sent to OpenAI Responses API using a user-entered model and API key (default `gpt-4.1-mini`) |
| Privacy | No constant mic recording, no recording of Accessibility events, no background notification uploads, no embedded API key |

## Build APK using Android Studio on a computer

1. Install Android Studio from https://developer.android.com/studio .
2. Extract this entire ZIP and choose **Open** > the `JarvisMobile` project folder.
3. Configure Android SDK 35 if prompted. Use Gradle 8.11.1 and JDK 17 if the IDE asks.
4. Sync Gradle; allow the Android plugin dependencies to download (internet required).
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Transfer the generated file `app/build/outputs/apk/debug/app-debug.apk` to your Android device.
7. Open the APK on the Android device and allow installation from the specific file manager/browser when Android prompts.

**Important:** This source package does **not** contain a checked-in Gradle wrapper JAR. Android Studio can use/configure Gradle locally; alternatively run the CI workflow below.

## Build APK using GitHub Actions (no local Android SDK)

1. Make a private GitHub repository and add the **contents** of this project (not only the ZIP archive) so `app/`, `settings.gradle`, and `.github/workflows/android-apk.yml` all exist at the repository root.
2. Open the repository's **Actions** tab and select **Build Android APK**.
3. Click **Run workflow** (or push to `main`).
4. On a successful run, find **Artifacts** > `Jarvis-Mobile-debug-APK`.
5. Download the artifact ZIP, extract `app-debug.apk`, and install it on Android.

Debug APKs are signed automatically with an Android debug key, which is for personal testing, not Play Store publication. Building through GitHub Actions uses the internet and your GitHub account, but no personal API key should be uploaded with the source.

## Configure the app once installed

1. Open **Jarvis Mobile** and grant **Microphone** on your phone when prompted.
2. Tap **ENABLE SCREEN CONTROL**; Android **Settings > Accessibility > Installed apps > Jarvis Mobile > Use service**. Review the warning and enable only if you trust the app. This allows JARVIS to inspect active screen elements and issue clicks / gestures for commands you request.
3. Optional: grant **Contacts** to dial names, **Notification access** to read notifications, and **Display over other apps** for the bubble.
4. Start the floating mic with **START FLOATING MIC BUBBLE**. An ongoing notification lets you stop it, or use **STOP FLOATING MIC BUBBLE** in the app.
5. Choose speech language: default Hindi (`hi-IN`); toggle to Indian English (`en-IN`) if needed. The underlying speech provider's support and data handling vary by device.
6. For general AI answers, you may enter **your own** OpenAI API key, choose a model, and explicitly enable cloud AI. The key is encrypted at rest with Android Keystore. Optional cloud AI is *not* needed for the built-in device controls.

**Android Restricted settings:** On some Android 13+ devices, sideloaded apps cannot initially enable Accessibility or notification services. If Android shows **Restricted setting**, go to **Settings > Apps > Jarvis Mobile > ⋮ > Allow restricted settings**, then return to Accessibility. Exact menu wording varies by device. Enable only for apps you trust.

## Privacy & security boundaries

- This is a user-controlled accessibility aid, **not** a hidden remote-control or surveillance agent.
- Microphone recognition happens only after the user taps a button or the mic bubble. No always-on hotword / background listening is implemented. Some system speech providers send speech to remote servers even when JARVIS cloud AI is off. The **Prefer on-device** setting requests a local speech provider when supported, but availability depends on the device.
- Only **unrecognized spoken text**, and only after explicit cloud enablement, is sent to the OpenAI Responses API. Screenshots, screen contents, contacts, and notification contents are **not** sent to AI.
- Entered AI API keys are stored encrypted at rest in Android Keystore. Device compromise or an unlocked handset can still put keys at risk; production apps should use a server-side key proxy with quotas.
- Password entry is not automated. Sensitive UI taps (such as purchase / payments / delete / permission approvals) are restricted, but no heuristic can guarantee full safety; review the current screen before issuing a command.
- Contacts only open `ACTION_DIAL`, never call without user pressing Call. SMS only opens a draft. Payment, installation, bank-transfer and permission approvals require direct user involvement.
- Reading notifications can reveal sensitive data aloud; use only in a private location. Notification reader tries to omit messages containing OTP / verification keywords, but it is not a complete classifier.
- Speech recognition, TTS, Accessibility nodes, intent resolution, foreground services, and overlay permissions behave differently across Android brands / versions. Controls aren't guaranteed in secure apps or banking screens.
- This app is not a system/default assistant and **cannot grant itself permissions, silently unlock your phone, access protected data, or control all settings on every device**.
- Turning off the Accessibility service and removing the overlay permission is always possible from Android Settings. The floating bubble can be stopped via the ongoing notification.

## Dev checks

Command parser tests (needs only Java 17; includes argument checks):

```bash
mkdir -p tools/out
javac -encoding UTF-8 -d tools/out app/src/main/java/com/jarvis/mobile/CommandParser.java tools/ParserSmokeTest.java
java -cp tools/out com.jarvis.mobile.ParserSmokeTest
```

The GitHub workflow builds `:app:assembleDebug` using Android SDK 35. Actual device behavior should be verified after the build, especially speech engines, overlay permissions, Accessibility actions, flashlight control, dialer and notification permissions.

## Implementation notes

- `app/src/main/java/com/jarvis/mobile/CommandParser.java` — offline intent parser
- `CommandEngine.java` — command routing, Android intents, system services, optional AI fallback
- `JarvisAccessibilityService.java` — on-demand UI gestures, tap by visible text, typing into non-password fields
- `FloatingMicService.java` — user-enabled floating shortcut foreground service
- `ListenActivity.java` — visible push-to-talk session using Android `SpeechRecognizer`
- `NotificationReaderService.java` — on-demand current notification summary
- `AssistantAI.java` and `KeyVault.java` — optional HTTPS Responses API and encrypted key storage
- `.github/workflows/android-apk.yml` — automated APK build

---

Created as a best-effort buildable Android project. There is **no promise of compatibility on every Android handset without a device build/test**.

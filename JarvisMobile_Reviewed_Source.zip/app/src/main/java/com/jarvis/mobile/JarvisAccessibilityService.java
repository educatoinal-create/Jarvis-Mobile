package com.jarvis.mobile;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayDeque;
import java.util.Locale;

/** Acts only when the user has manually enabled this service and requested a command. */
public final class JarvisAccessibilityService extends AccessibilityService {
    private static volatile JarvisAccessibilityService active;
    public static JarvisAccessibilityService get() { return active; }
    @Override public void onServiceConnected() { super.onServiceConnected(); active = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* No background collection. */ }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { active = null; super.onDestroy(); }

    public boolean global(int action) { return performGlobalAction(action); }

    public boolean tapText(String requested) {
        if (requested == null || requested.trim().isEmpty()) return false;
        String query = requested.toLowerCase(Locale.ROOT).trim();
        // High-risk and credential approval screens require direct user input.
        for (String forbidden : new String[]{"pay now", "pay ", "transfer", "purchase", "checkout", "delete", "otp", "password", "verify", "allow access", "grant permission", "पेमेंट", "भुगतान", "पासवर्ड", "अनुमति"}) {
            if (query.contains(forbidden)) return false;
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        try {
            ArrayDeque<AccessibilityNodeInfo> nodes = new ArrayDeque<>();
            nodes.add(root);
            AccessibilityNodeInfo partial = null;
            int count = 0;
            while (!nodes.isEmpty() && count++ < 600) {
                AccessibilityNodeInfo n = nodes.removeFirst();
                String label = ((n.getText() == null ? "" : n.getText().toString()) + " " +
                    (n.getContentDescription() == null ? "" : n.getContentDescription().toString())).trim().toLowerCase(Locale.ROOT);
                if (label.equals(query)) {
                    AccessibilityNodeInfo clickable = getClickable(n);
                    if (clickable != null) return clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                }
                if (partial == null && label.contains(query)) partial = n;
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo child = n.getChild(i);
                    if (child != null) nodes.addLast(child);
                }
            }
            if (partial != null) {
                AccessibilityNodeInfo clickable = getClickable(partial);
                return clickable != null && clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            return false;
        } catch (SecurityException ignored) { return false; }
    }
    private AccessibilityNodeInfo getClickable(AccessibilityNodeInfo node) {
        for (int i = 0; i < 8 && node != null; i++) {
            if (node.isClickable() && node.isEnabled() && node.isVisibleToUser() && !node.isPassword()) return node;
            node = node.getParent();
        }
        return null;
    }
    public boolean typeFocused(String text) {
        if (text == null || text.isEmpty() || text.length() > 2000) return false;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        try {
            AccessibilityNodeInfo focus = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (focus == null || !focus.isEditable()) focus = findEditable(root);
            if (focus == null || !focus.isEnabled() || focus.isPassword()) return false;
            Bundle b = new Bundle();
            b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            return focus.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
        } catch (SecurityException ignored) { return false; }
    }
    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo root) {
        ArrayDeque<AccessibilityNodeInfo> nodes = new ArrayDeque<>();
        nodes.add(root);
        int i = 0;
        while (!nodes.isEmpty() && i++ < 400) {
            AccessibilityNodeInfo n = nodes.removeFirst();
            if (n.isEditable() && !n.isPassword() && n.isVisibleToUser()) return n;
            for (int j = 0; j < n.getChildCount(); j++) {
                AccessibilityNodeInfo child = n.getChild(j);
                if (child != null) nodes.addLast(child);
            }
        }
        return null;
    }
    public boolean scroll(boolean down) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            ArrayDeque<AccessibilityNodeInfo> nodes = new ArrayDeque<>();
            nodes.add(root);
            int i = 0;
            while (!nodes.isEmpty() && i++ < 400) {
                AccessibilityNodeInfo n = nodes.removeFirst();
                if (n.isScrollable()) {
                    if (n.performAction(down ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) return true;
                }
                for (int j = 0; j < n.getChildCount(); j++) {
                    AccessibilityNodeInfo child = n.getChild(j);
                    if (child != null) nodes.addLast(child);
                }
            }
        }
        return swipe(down ? 0.72f : 0.27f, down ? 0.28f : 0.74f, 0.5f, 0.5f);
    }
    public boolean swipeHorizontal(boolean left) {
        return swipe(0.5f, 0.5f, left ? 0.8f : 0.2f, left ? 0.2f : 0.8f);
    }
    private boolean swipe(float y1, float y2, float x1, float x2) {
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        Path p = new Path();
        p.moveTo(w*x1, h*y1);
        p.lineTo(w*x2, h*y2);
        GestureDescription gesture = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p,0,350)).build();
        return dispatchGesture(gesture, null, null);
    }
}

package com.jarvis.mobile;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/** Reads current notifications only after explicit spoken request; retains none. */
public final class NotificationReaderService extends NotificationListenerService {
    public static volatile NotificationReaderService active;
    @Override public void onListenerConnected() { active = this; }
    @Override public void onListenerDisconnected() { active = null; }
    @Override public void onDestroy() { active = null; super.onDestroy(); }
    public String readActive() {
        try {
            StatusBarNotification[] items = getActiveNotifications();
            if (items == null || items.length == 0) return "No active notifications.";
            StringBuilder out = new StringBuilder("Your latest notifications: ");
            int n = 0;
            for (int i = items.length - 1; i >= 0 && n < 5; i--) {
                Notification note = items[i].getNotification();
                if (note == null || note.extras == null) continue;
                CharSequence title = note.extras.getCharSequence(Notification.EXTRA_TITLE);
                CharSequence body = note.extras.getCharSequence(Notification.EXTRA_TEXT);
                String t = title == null ? "" : title.toString();
                String b = body == null ? "" : body.toString();
                String combined = t + " " + b;
                // Do not speak one-time passwords or other verification codes aloud.
                if (combined.toLowerCase().matches("(?s).*(otp|verification code|one.time password|security code|पासकोड|ओटीपी).*(?s)")) continue;
                if (combined.trim().isEmpty()) continue;
                if (combined.length() > 120) combined = combined.substring(0,120);
                out.append(++n).append(". ").append(combined).append(". ");
            }
            return n == 0 ? "No notifications I can read safely." : out.toString();
        } catch (Exception e) { return "Unable to access notifications right now."; }
    }
}

package com.jarvis.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

/** A self-contained native setup and push-to-talk UI, without third-party UI dependencies. */
public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(9,16,32), CARD = Color.rgb(21,32,52);
    private static final int WHITE = Color.rgb(241,248,255), MUTED = Color.rgb(161,181,205);
    private static final int CYAN = Color.rgb(58,217,209), PURPLE = Color.rgb(137,121,255);
    private SharedPreferences prefs;
    private TextView status, last;
    private EditText apiEntry, modelEntry, typed;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("settings",MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUI();
    }
    private int dp(int n) { return Math.round(getResources().getDisplayMetrics().density*n); }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius)); return g;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        if (bold) v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return v;
    }
    private void addSpace(LinearLayout to, int height) {
        View blank = new View(this); to.addView(blank,new LinearLayout.LayoutParams(1,dp(height)));
    }
    private LinearLayout card(LinearLayout into, String title, String info) {
        LinearLayout c = column(); c.setPadding(dp(18),dp(17),dp(18),dp(17)); c.setBackground(shape(CARD,20));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.bottomMargin = dp(14); into.addView(c,p);
        c.addView(text(title,18,WHITE,true));
        if (info != null) { addSpace(c,5); c.addView(text(info,13,MUTED,false)); addSpace(c,12); }
        return c;
    }
    private Button button(LinearLayout into, String name, int color, Runnable action) {
        Button b = new Button(this); b.setText(name); b.setTextSize(14);
        b.setAllCaps(false); b.setTextColor(color == CYAN ? BG : WHITE);
        b.setBackground(shape(color,12));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,dp(50)); p.topMargin = dp(7); into.addView(b,p);
        b.setOnClickListener(v -> action.run());
        return b;
    }
    private EditText input(LinearLayout into, String hint, boolean secret, String initial) {
        EditText e = new EditText(this); e.setSingleLine(!hint.startsWith("Try"));
        e.setTextColor(WHITE); e.setHintTextColor(MUTED); e.setTextSize(15); e.setHint(hint);
        e.setPadding(dp(13),dp(10),dp(13),dp(10)); e.setBackground(shape(BG,12));
        if (secret) e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        if (initial != null) e.setText(initial);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,dp(54)); p.topMargin = dp(8); into.addView(e,p);
        return e;
    }
    @Override protected void onResume() { super.onResume(); if (status != null) updateStatus(); }
    private void updateStatus() {
        boolean access = JarvisAccessibilityService.get() != null;
        boolean contacts = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED;
        boolean microphone = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        boolean overlay = Settings.canDrawOverlays(this);
        status.setText((microphone ? "✓" : "○") + " Microphone   " + (access ? "✓" : "○") + " Screen Control\n" +
            (contacts ? "✓" : "○") + " Contacts        " + (overlay ? "✓" : "○") + " Floating overlay\n" +
            (KeyVault.read(this).isEmpty() ? "○" : "✓") + " Optional AI key    " +
            (FloatingMicService.active ? "✓ Mic bubble ON" : "○ Mic bubble OFF"));
        last.setText("Latest result: " + prefs.getString("last_response","No commands run yet."));
    }
    private void buildUI() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        LinearLayout root = column(); root.setPadding(dp(19),dp(28),dp(19),dp(30)); scroll.addView(root); setContentView(scroll);
        TextView kicker = text("✦  PERSONAL VOICE CONTROL",12,CYAN,true); root.addView(kicker); addSpace(root,10);
        TextView title = text("JARVIS",42,WHITE,true); root.addView(title);
        root.addView(text("Mobile AI Assistant  •  v1.0",17,MUTED,false)); addSpace(root,20);

        LinearLayout hero = card(root,"🎤  One tap. Your command.",
            "Hindi + English voice commands. Runs on your Android speech engine; supported providers may use cloud processing.");
        button(hero,"START VOICE COMMAND",CYAN,()->startListening());
        button(hero,"SEE COMMAND EXAMPLES",PURPLE,()->new android.app.AlertDialog.Builder(this)
            .setTitle("Try these commands")
            .setMessage("WhatsApp खोलो\nOpen Chrome\nBack जाओ\nHome screen\nनीचे स्क्रॉल करो\nClick Search\nType hello friend\nTorch on\nVolume down\nCall Mom\nBattery level\nRead notifications\nSet alarm at 7:30 am\nTimer 5 minutes\nYouTube पर lo-fi music सर्च करो\nSearch Delhi weather\n\nTo use screen controls inside other apps, enable Accessibility + the floating mic.")
            .setPositiveButton("Got it",(d,w)->{}).show());

        LinearLayout permissionCard = card(root,"🔐  Permissions & access",
            "You control each permission. Screen Control can read visible UI only to carry out your requested command.");
        status = text("Checking permissions...",14,CYAN,false); permissionCard.addView(status); addSpace(permissionCard,7);
        button(permissionCard,"1. ENABLE MICROPHONE",PURPLE,()->requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},11));
        button(permissionCard,"2. ENABLE SCREEN CONTROL",PURPLE,()-> {
            toast("Find Jarvis Mobile under Installed accessibility apps, then turn it on.");
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });
        button(permissionCard,"3. ENABLE CONTACTS (OPTIONAL)",PURPLE,()->requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},12));
        button(permissionCard,"4. NOTIFICATION ACCESS (OPTIONAL)",PURPLE,()->startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));
        button(permissionCard,"5. START FLOATING MIC BUBBLE",CYAN,()->startBubble());
        button(permissionCard,"STOP FLOATING MIC BUBBLE",Color.rgb(71,83,109),()-> {
            stopService(new Intent(this,FloatingMicService.class));
            new android.os.Handler(getMainLooper()).postDelayed(this::updateStatus,350);
        });

        LinearLayout lang = card(root,"🌐  Speech settings",
            "Hindi is the starting language. English commands work best with English recognition. Offline depends on installed speech packs.");
        Switch english = new Switch(this); english.setText("English recognition (off = Hindi)");
        english.setTextColor(WHITE); english.setChecked(prefs.getBoolean("english",false));
        english.setOnCheckedChangeListener((b,v)->prefs.edit().putBoolean("english",v).apply()); lang.addView(english);
        Switch offline = new Switch(this); offline.setText("Prefer on-device recognition, if supported");
        offline.setTextColor(WHITE); offline.setChecked(prefs.getBoolean("offline",false));
        offline.setOnCheckedChangeListener((b,v)->prefs.edit().putBoolean("offline",v).apply()); lang.addView(offline);

        LinearLayout ai = card(root,"✧  Optional AI questions",
            "Device commands run locally. For unrecognized questions only, Jarvis can send your spoken text to OpenAI if you enable this and provide your own API key. Usage may cost money.");
        Switch cloud = new Switch(this); cloud.setText("Enable cloud AI for questions"); cloud.setTextColor(WHITE);
        cloud.setChecked(prefs.getBoolean("cloud_enabled",false));
        cloud.setOnCheckedChangeListener((b,on)->prefs.edit().putBoolean("cloud_enabled",on).apply()); ai.addView(cloud);
        apiEntry = input(ai,"Enter OpenAI API key (stored encrypted)",true,null);
        modelEntry = input(ai,"API model",false,prefs.getString("model","gpt-4.1-mini"));
        button(ai,"SAVE AI SETTINGS",PURPLE,()->{
            String model = modelEntry.getText().toString().trim();
            if (!model.matches("[A-Za-z0-9._:-]{2,100}")) { toast("Enter a valid API model identifier."); return; }
            prefs.edit().putString("model",model).apply();
            String secret = apiEntry.getText().toString().trim();
            if (!secret.isEmpty()) {
                if (!KeyVault.save(this,secret)) { toast("Could not encrypt the API key."); return; }
                apiEntry.setText("");
            }
            updateStatus(); toast("AI settings saved on this phone.");
        });
        button(ai,"REMOVE SAVED API KEY",Color.rgb(71,83,109),()->{ KeyVault.clear(this); updateStatus(); toast("Saved key removed."); });

        LinearLayout test = card(root,"⌨  Test without speaking", "Run a typed command. Use the mic bubble for screen operations in other apps.");
        typed = input(test,"Try: open YouTube",false,null);
        button(test,"RUN TEXT COMMAND",CYAN,()->{
            String phrase = typed.getText().toString().trim();
            if (!phrase.isEmpty()) CommandEngine.execute(this,phrase,message->{ updateStatus(); Speaker.speak(this,message); });
        });
        last = text("Latest result: —",13,MUTED,false); addSpace(test,12); test.addView(last);
        button(test,"CLEAR LAST RESULT",Color.rgb(71,83,109),()->{
            prefs.edit().remove("last_response").apply(); updateStatus();
        });

        LinearLayout privacy = card(root,"🛡  Privacy & limitations",
            "No background screen logging; no passwords, OTP collection, auto-payments or silent sending. Mic only listens after you tap. Notification contents remain on device. The floating shortcut uses an ongoing Android foreground service. Turn any permission off in Android settings.");
        privacy.addView(text("Accessibility grants strong control: enable only if you trust this app. Android may restrict controls on secure screens.",13,CYAN,false));
        updateStatus();
    }
    private void toast(String m) { Toast.makeText(this,m,Toast.LENGTH_LONG).show(); }
    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},11);
            return;
        }
        startActivity(new Intent(this,ListenActivity.class));
    }
    private void startBubble() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow Display over other apps, return here, then tap Start Floating Mic again.");
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));
            startActivity(intent); return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},15);
            toast("After the notification choice, tap Start Floating Mic again.");
            return;
        }
        try {
            Intent i = new Intent(this,FloatingMicService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            new android.os.Handler(getMainLooper()).postDelayed(this::updateStatus,650);
        } catch (Exception ex) { toast("Unable to start floating mic on this device."); }
    }
    @Override public void onRequestPermissionsResult(int req,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(req,permissions,results);
        updateStatus();
        if (req == 11 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening();
    }
}

package com.jarvis.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.TextView;

/** Optional, clearly visible foreground mic shortcut. It does NOT keep the mic open. */
public final class FloatingMicService extends Service {
    public static volatile boolean active;
    private static final String CHANNEL = "jarvis_mic_shortcut";
    private static final String STOP = "com.jarvis.mobile.STOP_FLOATING_MIC";
    private WindowManager manager;
    private TextView bubble;
    private WindowManager.LayoutParams layout;
    private int dp(int d) { return Math.round(getResources().getDisplayMetrics().density*d); }
    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(CHANNEL,"Jarvis voice shortcut",NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Shown while the floating microphone shortcut is active.");
        nm.createNotificationChannel(channel);
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        try {
            Intent open = new Intent(this,ListenActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent press = PendingIntent.getActivity(this,100,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Intent stopIntent = new Intent(this,FloatingMicService.class).setAction(STOP);
            PendingIntent stop = PendingIntent.getService(this,101,stopIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification notification = new Notification.Builder(this,CHANNEL)
                .setContentTitle("Jarvis floating mic is enabled")
                .setContentText("Tap the bubble or here to speak. No continuous listening.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(press)
                .addAction(new Notification.Action.Builder(null,"Turn off",stop).build())
                .setOngoing(true)
                .build();
            if (Build.VERSION.SDK_INT >= 34) startForeground(84,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(84,notification);
            active = true;
            if (bubble == null) showBubble();
        } catch (Exception ex) { stopSelf(); }
        return START_NOT_STICKY;
    }
    private void showBubble() {
        manager = (WindowManager)getSystemService(WINDOW_SERVICE);
        bubble = new TextView(this);
        bubble.setText("🎙"); bubble.setTextSize(27); bubble.setGravity(Gravity.CENTER);
        bubble.setContentDescription("Tap to speak to Jarvis, hold and drag to move");
        bubble.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(19,181,190),Color.rgb(114,83,210)});
        bg.setShape(GradientDrawable.OVAL);
        bubble.setBackground(bg); bubble.setElevation(dp(12));
        layout = new WindowManager.LayoutParams(dp(62),dp(62),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
        layout.gravity = Gravity.TOP|Gravity.START;
        layout.x = getResources().getDisplayMetrics().widthPixels-dp(82);
        layout.y = dp(300);
        bubble.setOnTouchListener(new android.view.View.OnTouchListener() {
            private float downX,downY;
            private int originX,originY;
            private boolean moved;
            @Override public boolean onTouch(android.view.View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX=event.getRawX(); downY=event.getRawY(); originX=layout.x; originY=layout.y; moved=false; return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx=(int)(event.getRawX()-downX), dy=(int)(event.getRawY()-downY);
                        if (Math.abs(dx)>dp(8) || Math.abs(dy)>dp(8)) moved=true;
                        if (moved) {
                            layout.x=Math.max(0,Math.min(getResources().getDisplayMetrics().widthPixels-dp(62),originX+dx));
                            layout.y=Math.max(0,Math.min(getResources().getDisplayMetrics().heightPixels-dp(62),originY+dy));
                            try { manager.updateViewLayout(bubble,layout); } catch (Exception ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            try { startActivity(new Intent(FloatingMicService.this,ListenActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
                            catch (Exception ignored) { }
                        }
                        return true;
                    default: return false;
                }
            }
        });
        manager.addView(bubble,layout);
    }
    @Override public void onDestroy() {
        active = false;
        if (bubble != null && manager != null) {
            try { manager.removeView(bubble); } catch (Exception ignored) { }
            bubble=null;
        }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}

package com.jarvis.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;

/** A short, user-initiated recognition session; never auto-restarts in background. */
public final class ListenActivity extends Activity implements RecognitionListener {
    private SpeechRecognizer recognizer;
    private TextView prompt;
    private boolean handled;
    private int dp(int p) { return Math.round(getResources().getDisplayMetrics().density*p); }
    private GradientDrawable panel() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.rgb(16,29,49)); d.setCornerRadius(dp(26));
        d.setStroke(dp(1), Color.rgb(54,108,125)); return d;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        getWindow().setDimAmount(0.25f);
        LinearLayout outer = new LinearLayout(this); outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackground(panel()); outer.setPadding(dp(22),dp(25),dp(22),dp(25));
        TextView title = new TextView(this); title.setText("◉  JARVIS LISTENING"); title.setTextSize(20);
        title.setTextColor(Color.rgb(78,229,213)); title.setGravity(Gravity.CENTER); outer.addView(title);
        prompt = new TextView(this); prompt.setText("Speak Hindi or English…"); prompt.setTextSize(16);
        prompt.setTextColor(Color.WHITE); prompt.setGravity(Gravity.CENTER);
        prompt.setPadding(dp(8),dp(24),dp(8),dp(18)); outer.addView(prompt);
        TextView hint = new TextView(this); hint.setText("Your mic turns off at the end of each command.\nTap CANCEL to stop now.");
        hint.setTextColor(Color.rgb(170,188,205)); hint.setTextSize(12); hint.setGravity(Gravity.CENTER);
        outer.addView(hint);
        TextView cancel = new TextView(this); cancel.setText("CANCEL"); cancel.setTextSize(16);
        cancel.setTextColor(Color.WHITE); cancel.setGravity(Gravity.CENTER);
        cancel.setPadding(dp(8),dp(22),dp(8),dp(4)); outer.addView(cancel);
        cancel.setOnClickListener(v -> finish());
        setContentView(outer);
        getWindow().setLayout(getResources().getDisplayMetrics().widthPixels-dp(36),WindowManager.LayoutParams.WRAP_CONTENT);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            prompt.setText("Microphone permission not granted."); return;
        }
        new Handler(Looper.getMainLooper()).postDelayed(this::startRecognition,250);
    }
    private void startRecognition() {
        if (isFinishing()) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            prompt.setText("No Android speech recognition service is installed. Install or enable a speech provider."); return;
        }
        try {
            boolean offline = getSharedPreferences("settings",MODE_PRIVATE).getBoolean("offline",false);
            if (offline && Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this))
                recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            else recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(this);
            Intent request = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            request.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            boolean english = getSharedPreferences("settings",MODE_PRIVATE).getBoolean("english",false);
            request.putExtra(RecognizerIntent.EXTRA_LANGUAGE,english ? "en-IN" : "hi-IN");
            request.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,english ? "en-IN" : "hi-IN");
            request.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
            request.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);
            if (offline) request.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);
            if (Build.VERSION.SDK_INT >= 34) request.putExtra(RecognizerIntent.EXTRA_ENABLE_LANGUAGE_DETECTION,true);
            recognizer.startListening(request);
        } catch (Exception ex) { prompt.setText("Speech engine unavailable. Try disabling Offline mode or choosing English."); }
    }
    @Override public void onReadyForSpeech(Bundle params) { prompt.setText("🎙  I'm listening…"); }
    @Override public void onBeginningOfSpeech() { prompt.setText("Hearing you…"); }
    @Override public void onRmsChanged(float rmsdB) { }
    @Override public void onBufferReceived(byte[] buffer) { }
    @Override public void onEndOfSpeech() { prompt.setText("Understanding…"); }
    @Override public void onError(int error) {
        if (handled || isFinishing()) return;
        String description;
        switch (error) {
            case SpeechRecognizer.ERROR_NO_MATCH: description = "Didn't catch that. Close and try again."; break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: description = "No speech detected. Close and retry."; break;
            case SpeechRecognizer.ERROR_NETWORK: description = "Speech provider network error. Try on-device recognition."; break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: description = "Microphone permission missing."; break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: description = "Speech engine busy. Retry."; break;
            default: description = "Speech recognition error (" + error + "). Retry.";
        }
        prompt.setText(description);
    }
    @Override public void onResults(Bundle results) {
        if (handled) return;
        ArrayList<String> words = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (words == null || words.isEmpty()) { prompt.setText("No words recognized."); return; }
        String spoken = words.get(0).trim();
        if (spoken.isEmpty()) return;
        handled = true;
        prompt.setText("✓ " + spoken);
        // Finish the dialog first so Accessibility targets the app beneath it, not this dialog.
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            finish();
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                CommandEngine.execute(getApplicationContext(),spoken,answer -> Speaker.speak(getApplicationContext(),answer));
            },550);
        },220);
    }
    @Override public void onPartialResults(Bundle partialResults) {
        ArrayList<String> words = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (!handled && words != null && !words.isEmpty()) prompt.setText(words.get(0));
    }
    @Override public void onEvent(int eventType, Bundle params) { }
    @Override public void onDestroy() {
        if (recognizer != null) { recognizer.cancel(); recognizer.destroy(); recognizer = null; }
        super.onDestroy();
    }
}

package com.jarvis.mobile;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Android-free voice command parsing, independently smoke-testable with javac. */
public final class CommandParser {
    public enum Type {
        OPEN_APP, OPEN_SETTINGS, SEARCH_WEB, SEARCH_YOUTUBE, BACK, HOME, RECENTS,
        NOTIFICATIONS, QUICK_SETTINGS, LOCK, TAP, TYPE, SCROLL_DOWN, SCROLL_UP,
        SWIPE_LEFT, SWIPE_RIGHT, TORCH_ON, TORCH_OFF, TORCH_TOGGLE, VOLUME_UP,
        VOLUME_DOWN, MUTE, BATTERY, TIME, CALL, MESSAGE, ALARM, TIMER,
        READ_NOTIFICATIONS, UNKNOWN
    }
    public static final class Result {
        public final Type type;
        public final String argument;
        public final int first;
        public final int second;
        public Result(Type type, String argument) { this(type, argument, -1, -1); }
        public Result(Type type, String argument, int first, int second) {
            this.type = type; this.argument = argument; this.first = first; this.second = second;
        }
    }
    private static final Pattern TIME = Pattern.compile("(?:at|for|का|को|बजे)?\\s*(\\d{1,2})(?::(\\d{1,2}))?\\s*(am|pm|a\\.m\\.|p\\.m\\.)?");
    private CommandParser() { }
    private static Result of(Type action) { return new Result(action, ""); }
    private static boolean has(String s, String... keywords) {
        for (String k : keywords) if (s.contains(k)) return true;
        return false;
    }
    private static String strip(String s, String... prefixes) {
        for (String prefix : prefixes) if (s.startsWith(prefix)) return s.substring(prefix.length()).trim();
        return s;
    }
    private static String cleanup(String s) {
        return s.replaceAll("(?i)\\s*(please|कर दो|करना|जरा|ज़रा|करो|दीजिए|दे दो|karo|khol do|खोल दो|खोलो|open|launch)\\s*$", "").trim();
    }
    public static Result parse(String speech) {
        if (speech == null) return of(Type.UNKNOWN);
        String s = speech.trim().toLowerCase(Locale.ROOT).replaceAll("[.!?।]+$", "").trim();
        s = s.replaceFirst("(?iu)^(?:hey\\s+|ok\\s+)?(?:jarvis|जार्विस|जर्विस|जाविस)[,،:\\s]+", "");
        s = strip(s, "please ", "प्लीज़ ");
        if (s.isEmpty()) return of(Type.UNKNOWN);
        if (has(s, "flashlight", "torch", "टॉर्च", "फ्लैशलाइट")) {
            if (has(s,"off","बंद","बुझा")) return of(Type.TORCH_OFF);
            if (has(s,"on","चालू","जला")) return of(Type.TORCH_ON);
            return of(Type.TORCH_TOGGLE);
        }
        if (has(s, "read notification", "notification पढ़", "नोटिफिकेशन पढ़", "नोटिफिकेशन सुन", "what notifications")) return of(Type.READ_NOTIFICATIONS);
        if (has(s, "quick setting", "क्विक सेटिंग")) return of(Type.QUICK_SETTINGS);
        if (has(s, "show notification", "open notification", "notification panel", "नोटिफिकेशन खोल", "नोटिफिकेशन दिखा")) return of(Type.NOTIFICATIONS);
        if (has(s, "lock screen", "lock phone", "फोन लॉक", "स्क्रीन लॉक")) return of(Type.LOCK);
        if (has(s, "recent apps", "recent app", "recents", "रीसेंट ऐप", "रिसेंट ऐप")) return of(Type.RECENTS);
        if (s.equals("back") || s.equals("go back") || has(s,"वापस जाओ","पीछे जाओ","बैक जाओ","back जाओ")) return of(Type.BACK);
        if (s.equals("home") || has(s,"home screen","go home","होम स्क्रीन","होम जाओ")) return of(Type.HOME);
        if (has(s,"scroll down", "नीचे स्क्रॉल", "नीचे स्क्रोल", "scroll नीचे", "स्क्रोल डाउन")) return of(Type.SCROLL_DOWN);
        if (has(s,"scroll up", "ऊपर स्क्रॉल", "ऊपर स्क्रोल", "scroll ऊपर", "स्क्रोल अप")) return of(Type.SCROLL_UP);
        if (has(s,"swipe left", "बाएं स्वाइप", "लेफ्ट स्वाइप")) return of(Type.SWIPE_LEFT);
        if (has(s,"swipe right", "दाएं स्वाइप", "राइट स्वाइप")) return of(Type.SWIPE_RIGHT);
        if (has(s,"volume up", "increase volume", "आवाज़ बढ़", "आवाज बढ़", "वॉल्यूम बढ़")) return of(Type.VOLUME_UP);
        if (has(s,"volume down", "decrease volume", "आवाज़ कम", "आवाज कम", "वॉल्यूम कम")) return of(Type.VOLUME_DOWN);
        if (s.equals("mute") || has(s,"mute volume", "साउंड बंद", "आवाज़ म्यूट", "साइलेंट कर")) return of(Type.MUTE);
        if (has(s,"battery level", "battery percentage", "battery कितना", "बैटरी कितनी", "बैटरी लेवल")) return of(Type.BATTERY);
        if (s.equals("time") || has(s,"what time", "समय क्या", "टाइम क्या", "कितने बजे")) return of(Type.TIME);
        if (s.startsWith("type ") || s.startsWith("write ") || s.startsWith("लिखो ") || s.startsWith("टाइप ") || s.startsWith("लिख दो ")) {
            return new Result(Type.TYPE, strip(s,"type ", "write ", "लिखो ", "टाइप ", "लिख दो "));
        }
        if (s.startsWith("tap ") || s.startsWith("click ") || s.startsWith("press ") || s.startsWith("क्लिक ") || s.startsWith("दबाओ ") || s.startsWith("टैप ")) {
            String a = strip(s,"tap ","click ","press ","क्लिक ","दबाओ ","टैप ");
            a = a.replaceAll("(?i)( button| बटन| पर क्लिक करो| पर टैप करो)$", "").trim();
            return new Result(Type.TAP, a);
        }
        if (s.endsWith(" पर क्लिक करो") || s.endsWith(" पर टैप करो")) {
            return new Result(Type.TAP, s.replaceAll(" पर (क्लिक|टैप) करो$", "").trim());
        }
        if (s.startsWith("call ") || s.startsWith("dial ") || s.startsWith("कॉल ") || s.startsWith("फोन ")) {
            return new Result(Type.CALL, cleanup(strip(s,"call ","dial ","कॉल ","फोन ")));
        }
        if (s.endsWith(" को कॉल करो") || s.endsWith(" को फोन लगाओ") || s.endsWith(" को कॉल लगाओ")) {
            return new Result(Type.CALL, s.replaceAll(" को (कॉल करो|फोन लगाओ|कॉल लगाओ)$", "").trim());
        }
        if (s.startsWith("message ") || s.startsWith("sms ") || s.startsWith("मैसेज ")) {
            return new Result(Type.MESSAGE, strip(s,"message ","sms ","मैसेज "));
        }
        if (s.startsWith("set alarm ") || s.startsWith("alarm ") || s.startsWith("अलार्म ")) {
            String t = strip(s,"set alarm ","alarm ","अलार्म ");
            int[] hm = parseClock(t);
            return hm == null ? new Result(Type.UNKNOWN,s) : new Result(Type.ALARM,"",hm[0],hm[1]);
        }
        if (s.startsWith("set timer ") || s.startsWith("timer ") || s.startsWith("टाइमर ")) {
            String t = strip(s,"set timer ","timer ","टाइमर ");
            Matcher m = Pattern.compile("(\\d{1,4})").matcher(t);
            if (m.find()) {
                int n = Integer.parseInt(m.group(1));
                int sec = has(t,"second","सेकंड") ? n : n * 60;
                if (n > 0 && sec <= 86400) return new Result(Type.TIMER,"",sec,0);
            }
        }
        if (has(s,"youtube search", "search youtube", "यूट्यूब पर", "youtube पर")) {
            String t = s.replaceFirst("(?i)^(youtube search|search youtube|यूट्यूब पर|youtube पर)\\s*", "");
            return new Result(Type.SEARCH_YOUTUBE,cleanup(t.replaceAll("(?i)^(search|सर्च करो|खोजो)\\s*", "").replaceAll("(?i)\\s*(सर्च|search|खोजो)\\s*(करो)?$", "")));
        }
        if (s.startsWith("search ") || s.startsWith("google ") || s.startsWith("सर्च ") || s.startsWith("खोजो ")) {
            return new Result(Type.SEARCH_WEB,cleanup(strip(s,"search ","google ","सर्च ","खोजो ")));
        }
        if (s.startsWith("open ") || s.startsWith("launch ") || s.startsWith("खोलो ") || s.startsWith("खोल ")) {
            String app = cleanup(strip(s,"open ","launch ","खोलो ","खोल "));
            if (has(app,"settings", "सेटिंग")) return new Result(Type.OPEN_SETTINGS,app);
            return new Result(Type.OPEN_APP, app);
        }
        if (s.endsWith(" खोलो") || s.endsWith(" खोल दो") || s.endsWith(" ओपन करो")) {
            String app = cleanup(s.replaceAll(" (खोलो|खोल दो|ओपन करो)$", ""));
            if (has(app,"settings", "सेटिंग")) return new Result(Type.OPEN_SETTINGS,app);
            return new Result(Type.OPEN_APP,app);
        }
        if (s.equals("settings") || s.equals("सेटिंग्स")) return new Result(Type.OPEN_SETTINGS,"settings");
        return new Result(Type.UNKNOWN, speech.trim());
    }
    static int[] parseClock(String phrase) {
        Matcher m = TIME.matcher(phrase);
        while (m.find()) {
            int h = Integer.parseInt(m.group(1));
            int min = m.group(2) == null ? 0 : Integer.parseInt(m.group(2));
            String ap = m.group(3);
            if (ap != null) {
                if (h < 1 || h > 12) return null;
                if (ap.toLowerCase(Locale.ROOT).startsWith("p") && h != 12) h += 12;
                if (ap.toLowerCase(Locale.ROOT).startsWith("a") && h == 12) h = 0;
            }
            if (h >= 0 && h <= 23 && min >= 0 && min <= 59) return new int[]{h,min};
        }
        return null;
    }
}

package com.jarvis.mobile;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

/** Uses the installed Android text-to-speech engine, never a hidden microphone loop. */
public final class Speaker {
    private static TextToSpeech tts;
    private static boolean ready;
    private static String pending;
    private static final Handler HANDLER = new Handler(Looper.getMainLooper());
    private Speaker() { }
    public static void speak(Context context, String message) {
        if (message == null || message.trim().isEmpty()) return;
        HANDLER.post(() -> {
            String voiceText = message.length() > 480 ? message.substring(0,480) : message;
            if (tts == null) {
                pending = voiceText;
                tts = new TextToSpeech(context.getApplicationContext(), status -> {
                    ready = status == TextToSpeech.SUCCESS;
                    if (ready) {
                        Locale hindi = new Locale("hi","IN");
                        int supported = tts.isLanguageAvailable(hindi);
                        tts.setLanguage(supported >= TextToSpeech.LANG_AVAILABLE ? hindi : Locale.ENGLISH);
                        tts.setSpeechRate(1.04f);
                        if (pending != null) tts.speak(pending,TextToSpeech.QUEUE_FLUSH,null,"jarvis-voice");
                        pending = null;
                    }
                });
            } else if (ready) tts.speak(voiceText, TextToSpeech.QUEUE_FLUSH,null,"jarvis-voice");
            else pending = voiceText;
        });
    }
}

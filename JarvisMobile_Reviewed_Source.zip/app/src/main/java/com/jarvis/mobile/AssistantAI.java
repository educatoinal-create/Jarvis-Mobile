package com.jarvis.mobile;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/** Optional cloud Q&A: unrecognized user utterance only. No accessibility data or contacts sent. */
public final class AssistantAI {
    private static final ExecutorService POOL = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private AssistantAI() { }
    public static void ask(Context context, String message, Consumer<String> callback) {
        String apiKey = KeyVault.read(context);
        if (apiKey.isEmpty()) { callback.accept("Add your API key in Jarvis settings to use AI questions."); return; }
        String model = context.getSharedPreferences("settings",Context.MODE_PRIVATE).getString("model", "gpt-4.1-mini");
        POOL.execute(() -> {
            HttpURLConnection connection = null;
            String result;
            try {
                URL url = new URL("https://api.openai.com/v1/responses");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(25000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Authorization","Bearer " + apiKey);
                connection.setRequestProperty("Content-Type","application/json; charset=utf-8");
                JSONObject payload = new JSONObject();
                payload.put("model",model);
                payload.put("instructions","You are Jarvis Mobile, a concise, helpful bilingual Hindi-English voice assistant. Answer the user's text question. You cannot access or control the phone, so never claim you have completed device actions. Keep replies short for text to speech.");
                payload.put("input",message);
                payload.put("max_output_tokens",240);
                payload.put("store",false);
                try (OutputStream out = connection.getOutputStream()) {
                    out.write(payload.toString().getBytes(StandardCharsets.UTF_8));
                }
                int code = connection.getResponseCode();
                if (code < 200 || code >= 300) {
                    result = "AI request failed (HTTP " + code + "). Check API key, credits and model.";
                } else {
                    String body = readStream(connection.getInputStream());
                    JSONObject response = new JSONObject(body);
                    StringBuilder b = new StringBuilder();
                    JSONArray outputs = response.optJSONArray("output");
                    if (outputs != null) for (int i = 0; i < outputs.length(); i++) {
                        JSONArray content = outputs.optJSONObject(i) == null ? null : outputs.optJSONObject(i).optJSONArray("content");
                        if (content != null) for (int j = 0; j < content.length(); j++) {
                            JSONObject c = content.optJSONObject(j);
                            if (c != null && "output_text".equals(c.optString("type"))) b.append(c.optString("text"));
                        }
                    }
                    result = b.length() == 0 ? "AI returned no text." : b.toString();
                }
            } catch (Exception e) { result = "AI network error. Check your connection and settings."; }
            finally { if (connection != null) connection.disconnect(); }
            String finalResult = result;
            MAIN.post(() -> callback.accept(finalResult));
        });
    }
    private static String readStream(InputStream in) throws Exception {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))) {
            StringBuilder b = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null && b.length() < 400_000) b.append(line);
            return b.toString();
        }
    }
}

package com.jarvis.mobile;

import android.Manifest;
import android.accessibilityservice.AccessibilityService;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

public final class CommandEngine {
    private static boolean torchOn;
    private CommandEngine() { }
    private static String say(Context context, String message, Consumer<String> callback) {
        context.getSharedPreferences("settings",Context.MODE_PRIVATE).edit().putString("last_response",message).apply();
        callback.accept(message);
        return message;
    }
    private static void launch(Context c, Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }
    public static void execute(Context ctx, String speech, Consumer<String> callback) {
        Context c = ctx.getApplicationContext();
        CommandParser.Result cmd = CommandParser.parse(speech);
        JarvisAccessibilityService as = JarvisAccessibilityService.get();
        String result;
        try {
            switch (cmd.type) {
                case HOME: result = global(as,AccessibilityService.GLOBAL_ACTION_HOME); break;
                case BACK: result = global(as,AccessibilityService.GLOBAL_ACTION_BACK); break;
                case RECENTS: result = global(as,AccessibilityService.GLOBAL_ACTION_RECENTS); break;
                case NOTIFICATIONS: result = global(as,AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); break;
                case QUICK_SETTINGS: result = global(as,AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS); break;
                case LOCK:
                    result = Build.VERSION.SDK_INT >= 28 ? global(as,AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) : "Lock screen requires Android 9 or later.";
                    break;
                case TAP: result = as == null ? needsAccessibility() :
                    (as.tapText(cmd.argument) ? "Tapped " + cmd.argument : "Could not tap that text. Secure actions must be done manually."); break;
                case TYPE: result = as == null ? needsAccessibility() :
                    (as.typeFocused(cmd.argument) ? "Text entered." : "Select an editable field first. Password fields are blocked."); break;
                case SCROLL_DOWN: result = as == null ? needsAccessibility() : as.scroll(true) ? "Scrolled down." : "Could not scroll."; break;
                case SCROLL_UP: result = as == null ? needsAccessibility() : as.scroll(false) ? "Scrolled up." : "Could not scroll."; break;
                case SWIPE_LEFT: result = as == null ? needsAccessibility() : as.swipeHorizontal(true) ? "Swiped left." : "Could not swipe."; break;
                case SWIPE_RIGHT: result = as == null ? needsAccessibility() : as.swipeHorizontal(false) ? "Swiped right." : "Could not swipe."; break;
                case TORCH_ON: result = torch(c,true); break;
                case TORCH_OFF: result = torch(c,false); break;
                case TORCH_TOGGLE: result = torch(c,!torchOn); break;
                case OPEN_APP: result = openApp(c,cmd.argument); break;
                case OPEN_SETTINGS: result = openSettings(c,cmd.argument); break;
                case SEARCH_WEB:
                    if (cmd.argument.isEmpty()) result = "What should I search for?";
                    else { launch(c,new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q=" + Uri.encode(cmd.argument)))); result = "Searching the web."; }
                    break;
                case SEARCH_YOUTUBE:
                    if (cmd.argument.isEmpty()) result = "What should I search on YouTube?";
                    else { launch(c,new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(cmd.argument)))); result = "Searching YouTube."; }
                    break;
                case VOLUME_UP: result = volume(c,AudioManager.ADJUST_RAISE); break;
                case VOLUME_DOWN: result = volume(c,AudioManager.ADJUST_LOWER); break;
                case MUTE: result = volume(c,AudioManager.ADJUST_MUTE); break;
                case BATTERY:
                    BatteryManager battery = (BatteryManager)c.getSystemService(Context.BATTERY_SERVICE);
                    int pct = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                    result = pct >= 0 ? "Battery is at " + pct + " percent." : "Battery percentage unavailable.";
                    break;
                case TIME: result = "It is " + new SimpleDateFormat("h:mm a",Locale.getDefault()).format(new Date()); break;
                case CALL: result = dial(c,cmd.argument); break;
                case MESSAGE: result = messageDraft(c,cmd.argument); break;
                case ALARM:
                    Intent alarm = new Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR,cmd.first).putExtra(AlarmClock.EXTRA_MINUTES,cmd.second);
                    launch(c,alarm); result = "Opening alarm setup for " + String.format(Locale.ROOT,"%02d:%02d",cmd.first,cmd.second) + "."; break;
                case TIMER:
                    Intent timer = new Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH,cmd.first);
                    launch(c,timer); result = "Opening timer setup."; break;
                case READ_NOTIFICATIONS:
                    NotificationReaderService nr = NotificationReaderService.active;
                    result = nr == null ? "Enable Notification access from the Jarvis setup screen first." : nr.readActive(); break;
                case UNKNOWN:
                default:
                    boolean cloud = c.getSharedPreferences("settings",Context.MODE_PRIVATE).getBoolean("cloud_enabled",false);
                    if (cloud && !KeyVault.read(c).isEmpty()) {
                        AssistantAI.ask(c,speech,answer -> say(c,answer,callback));
                        return;
                    }
                    result = "I didn't recognize that device command. Use Examples, or enable optional AI questions.";
            }
        } catch (Exception ex) {
            result = "That action could not be completed. The target app or system may restrict access.";
        }
        say(c,result,callback);
    }
    private static String needsAccessibility() { return "Turn on Jarvis Screen Control in Android Accessibility settings first."; }
    private static String global(JarvisAccessibilityService service, int action) {
        return service == null ? needsAccessibility() : service.global(action) ? "Done." : "The phone refused that action.";
    }
    private static String volume(Context c, int direction) {
        AudioManager audio = (AudioManager)c.getSystemService(Context.AUDIO_SERVICE);
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,direction,AudioManager.FLAG_SHOW_UI);
        return "Volume adjusted.";
    }
    private static String torch(Context c, boolean on) {
        try {
            CameraManager cm = (CameraManager)c.getSystemService(Context.CAMERA_SERVICE);
            for (String camera : cm.getCameraIdList()) {
                Boolean flash = cm.getCameraCharacteristics(camera).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(flash)) {
                    cm.setTorchMode(camera,on);
                    torchOn = on;
                    return on ? "Flashlight on." : "Flashlight off.";
                }
            }
            return "No flashlight available.";
        } catch (Exception ex) { return "Flashlight is unavailable, possibly because the camera is in use."; }
    }
    private static String openSettings(Context c, String target) {
        String s = target.toLowerCase(Locale.ROOT);
        String action = Settings.ACTION_SETTINGS;
        if (s.contains("wifi") || s.contains("wi-fi") || s.contains("वाईफाई") || s.contains("वाई फाई")) action = Settings.ACTION_WIFI_SETTINGS;
        else if (s.contains("bluetooth") || s.contains("ब्लूटूथ")) action = Settings.ACTION_BLUETOOTH_SETTINGS;
        else if (s.contains("accessibility") || s.contains("एक्सेसिबिलिटी")) action = Settings.ACTION_ACCESSIBILITY_SETTINGS;
        else if (s.contains("display") || s.contains("brightness") || s.contains("ब्राइटनेस")) action = Settings.ACTION_DISPLAY_SETTINGS;
        else if (s.contains("sound") || s.contains("आवाज") || s.contains("साउंड")) action = Settings.ACTION_SOUND_SETTINGS;
        launch(c,new Intent(action));
        return "Opening settings.";
    }
    private static String openApp(Context c, String name) {
        if (name == null || name.trim().isEmpty()) return "Tell me which app to open.";
        String wanted = name.toLowerCase(Locale.ROOT).trim();
        if (wanted.contains("settings") || wanted.contains("सेटिंग")) return openSettings(c,wanted);
        if (wanted.contains("camera") || wanted.contains("कैमरा")) {
            launch(c,new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA));
            return "Opening camera.";
        }
        if (wanted.equals("browser") || wanted.equals("ब्राउज़र")) {
            launch(c,new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com")));
            return "Opening browser.";
        }
        wanted = wanted.replace("व्हाट्सएप","whatsapp").replace("व्हाट्सऐप","whatsapp")
            .replace("यूट्यूब","youtube").replace("इंस्टाग्राम","instagram")
            .replace("टेलीग्राम","telegram").replace("फेसबुक","facebook")
            .replace("क्रोम","chrome").replace("मैप्स","maps").replace("फोन ऐप","phone");
        PackageManager pm = c.getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(query,0);
        ResolveInfo best = null;
        int score = 0;
        for (ResolveInfo info : apps) {
            String label = String.valueOf(info.loadLabel(pm)).toLowerCase(Locale.ROOT);
            String pkg = info.activityInfo.packageName.toLowerCase(Locale.ROOT);
            int current = label.equals(wanted) ? 4 : label.startsWith(wanted) ? 3 : label.contains(wanted) ? 2 : pkg.contains(wanted.replace(" ","")) ? 1 : 0;
            if (current > score) { best = info; score = current; }
        }
        if (best == null) return "App not found: " + name + ".";
        Intent open = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(best.activityInfo.packageName,best.activityInfo.name);
        launch(c,open);
        return "Opening " + best.loadLabel(pm) + ".";
    }
    private static String dial(Context c, String target) {
        String person = target.replaceAll("(?i)(को|call|कॉल|फोन)$", "").trim();
        if (person.isEmpty()) return "Tell me who to call.";
        String number = person.replaceAll("[\\s()+-]", "");
        if (!number.matches("\\d{6,15}")) {
            if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
                return "Enable Contacts permission in Jarvis before calling contact names.";
            String found = null;
            try (Cursor cursor = c.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                new String[]{"%" + person + "%"},null)) {
                if (cursor != null && cursor.moveToFirst()) found = cursor.getString(0);
            }
            if (found == null || found.trim().isEmpty()) return "No matching contact for " + person + ".";
            number = found;
        }
        launch(c,new Intent(Intent.ACTION_DIAL,Uri.parse("tel:" + Uri.encode(number))));
        return "Dialer opened. Tap Call to place the call.";
    }
    private static String messageDraft(Context c, String command) {
        String[] parts = command.trim().split("\\s+",2);
        if (parts.length == 0 || !parts[0].replaceAll("[+()-]","").matches("\\d{6,15}"))
            return "For SMS, say: message 9876543210 hello. This opens a draft; it won't send automatically.";
        Intent sms = new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:" + Uri.encode(parts[0])));
        if (parts.length > 1) sms.putExtra("sms_body",parts[1]);
        launch(c,sms);
        return "SMS draft opened. Review it before sending.";
    }
}

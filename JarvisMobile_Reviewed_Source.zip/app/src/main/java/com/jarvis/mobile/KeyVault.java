package com.jarvis.mobile;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** API secret encrypted at rest by Android Keystore. Never ships with a key. */
public final class KeyVault {
    private static final String ALIAS = "jarvis_mobile_ai_key_v1";
    private KeyVault() { }
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences("private", Context.MODE_PRIVATE); }
    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        SecretKey existing = (SecretKey) ks.getKey(ALIAS,null);
        if (existing != null) return existing;
        KeyGenerator gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build());
        return gen.generateKey();
    }
    public static boolean save(Context context, String secret) {
        try {
            if (secret == null || secret.trim().isEmpty()) { clear(context); return true; }
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key());
            byte[] encrypted = cipher.doFinal(secret.trim().getBytes(StandardCharsets.UTF_8));
            String packed = Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted,Base64.NO_WRAP);
            prefs(context).edit().putString("api_blob",packed).apply();
            return true;
        } catch (Exception ex) { return false; }
    }
    public static String read(Context context) {
        try {
            String packed = prefs(context).getString("api_blob", "");
            String[] sections = packed.split(":",2);
            if (sections.length != 2) return "";
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(sections[0],Base64.DEFAULT)));
            return new String(cipher.doFinal(Base64.decode(sections[1],Base64.DEFAULT)),StandardCharsets.UTF_8);
        } catch (Exception ex) { return ""; }
    }
    public static void clear(Context context) { prefs(context).edit().remove("api_blob").apply(); }
}

# JARVIS Mobile — पहले यह पढ़ें

**यह ZIP Android ऐप का पूरा source-code project है, APK नहीं है।** इसे APK में बदलने के लिए Android Studio या GitHub Actions पर Android build चलाना होगा। इस चैट के वातावरण में Android SDK उपलब्ध नहीं था, इसलिए मैंने बिना build किए APK होने का दावा नहीं किया है।

## APK कैसे बनाएं?

**Laptop / PC उपलब्ध है:**

1. ZIP extract करो और [Android Studio](https://developer.android.com/studio) में `JarvisMobile` folder खोलो।
2. पूछे तो JDK 17, Gradle 8.11.1 और Android SDK 35 install करो; Gradle sync पूरा होने दो।
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)** चलाओ।
4. तैयार APK `app/build/outputs/apk/debug/app-debug.apk` होगा। उसे मोबाइल में transfer करके install कर लो।

**Cloud build करना है:** प्रोजेक्ट की files किसी private GitHub repository के root में upload करो, फिर **Actions → Build Android APK → Run workflow**। Success होने पर Artifacts में APK मिलेगा। यह APK debug-signed होगा और testing के लिए install हो सकता है।

## Install होने के बाद

1. **Microphone** permission दो और ऐप का बड़ा **START VOICE COMMAND** बटन दबाकर बोलो।
2. **ENABLE SCREEN CONTROL** पर जाकर Accessibility settings से Jarvis Mobile service अपनी मर्ज़ी से ON करो। तभी Back / Home / Scroll / Click / Type जैसे commands काम करेंगे।
3. चाहो तो **START FLOATING MIC BUBBLE** दबाओ और **Display over other apps** permission दो। दूसरे ऐप के ऊपर mic bubble दिखाई देगा। इस पर tap करके command बोल सकते हो। यह बिना tap किए लगातार नहीं सुनता।
4. Contact नाम बोलकर dialer खोलने के लिए **Contacts** permission दो; नोटिफिकेशन सुनने के लिए अलग **Notification access** दो।
5. Simple phone controls के लिए API key नहीं चाहिए। General AI सवालों के लिए अपनी OpenAI key दे सकते हो; सिर्फ जब AI toggle ON होगा तभी पहचाने नहीं गए सवाल cloud पर जाएंगे और API charges लग सकते हैं।

## जरूरी सीमाएँ

- Android पर 100% phone control, hidden background microphone, automatic unlocking और बैंक सुरक्षा bypass उपलब्ध नहीं हैं।
- कॉल डायलर में खुलेगी लेकिन अपने आप Call button नहीं दबेगा। SMS draft खुलेगा लेकिन खुद send नहीं होगा।
- Screen Control संवेदनशील permission है। Android की चेतावनी पढ़कर ही ON करो; Settings में किसी भी समय OFF कर सकते हो।
- फोन मॉडल और Android restrictions के कारण कुछ commands नहीं चल सकते। असली फोन पर पूरी Android testing इस ZIP को बनाते समय नहीं हो पाई।
